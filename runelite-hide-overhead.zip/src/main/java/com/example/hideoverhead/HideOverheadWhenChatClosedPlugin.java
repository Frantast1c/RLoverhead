package com.example.hideoverhead;

import com.google.inject.Inject;
import net.runelite.api.Client;
import net.runelite.api.widgets.Widget;
import net.runelite.api.widgets.WidgetInfo;
import net.runelite.api.events.GameTick;
import net.runelite.client.config.ConfigManager;
import net.runelite.client.eventbus.Subscribe;
import net.runelite.client.plugins.Plugin;
import net.runelite.client.plugins.PluginDescriptor;

@PluginDescriptor(
    name = "Hide Overhead When Chat Closed",
    description = "Automatically hides 2D overhead chat when your chatbox is closed (uses Entity Hider config).",
    tags = {"chat", "overhead", "entity", "hider", "ui"}
)
public class HideOverheadWhenChatClosedPlugin extends Plugin
{
    private static final String ENTITY_HIDER_PLUGIN_NAME = "entityhider";
    private static final String ENTITY_HIDER_HIDE_PLAYERS_2D_KEY = "hidePlayers2d";

    @Inject
    private Client client;

    @Inject
    private ConfigManager configManager;

    private Boolean originalEntityHiderValue = null;
    private boolean lastChatboxOpen = true;

    @Override
    protected void startUp() throws Exception
    {
        try
        {
            Object cfg = configManager.getConfiguration(ENTITY_HIDER_PLUGIN_NAME, ENTITY_HIDER_HIDE_PLAYERS_2D_KEY);
            if (cfg instanceof Boolean)
            {
                originalEntityHiderValue = (Boolean) cfg;
            }
        }
        catch (Exception ex)
        {
            originalEntityHiderValue = null;
        }
    }

    @Override
    protected void shutDown() throws Exception
    {
        if (originalEntityHiderValue != null)
        {
            configManager.setConfiguration(ENTITY_HIDER_PLUGIN_NAME, ENTITY_HIDER_HIDE_PLAYERS_2D_KEY, originalEntityHiderValue);
        }
    }

    @Subscribe
    public void onGameTick(GameTick event)
    {
        Widget chatboxPanel = client.getWidget(WidgetInfo.CHATBOX_PANEL);
        boolean chatboxOpen = (chatboxPanel != null && !chatboxPanel.isHidden());

        if (chatboxOpen == lastChatboxOpen)
        {
            return;
        }

        lastChatboxOpen = chatboxOpen;

        if (!chatboxOpen)
        {
            if (originalEntityHiderValue == null)
            {
                Object cfg = configManager.getConfiguration(ENTITY_HIDER_PLUGIN_NAME, ENTITY_HIDER_HIDE_PLAYERS_2D_KEY);
                if (cfg instanceof Boolean)
                {
                    originalEntityHiderValue = (Boolean) cfg;
                }
            }
            configManager.setConfiguration(ENTITY_HIDER_PLUGIN_NAME, ENTITY_HIDER_HIDE_PLAYERS_2D_KEY, true);
        }
        else
        {
            boolean toSet = originalEntityHiderValue != null ? originalEntityHiderValue : false;
            configManager.setConfiguration(ENTITY_HIDER_PLUGIN_NAME, ENTITY_HIDER_HIDE_PLAYERS_2D_KEY, toSet);
        }
    }
}
